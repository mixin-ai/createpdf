package com.cn.mdhw.utils;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import com.cn.mdhw.common.excepion.ServiceException;
import com.cn.mdhw.manage.api.ReportData;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorker;
import com.itextpdf.tool.xml.XMLWorkerFontProvider;
import com.itextpdf.tool.xml.css.StyleAttrCSSResolver;
import com.itextpdf.tool.xml.html.CssAppliers;
import com.itextpdf.tool.xml.html.CssAppliersImpl;
import com.itextpdf.tool.xml.html.Tags;
import com.itextpdf.tool.xml.pipeline.css.CSSResolver;
import com.itextpdf.tool.xml.pipeline.css.CssResolverPipeline;
import com.itextpdf.tool.xml.pipeline.end.PdfWriterPipeline;
import com.itextpdf.tool.xml.pipeline.html.AbstractImageProvider;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipelineContext;
import org.apache.log4j.Logger;

import java.io.*;
import java.util.Map;

/**
 * @Author wh
 * @Date 7/23/25
 * @Descripted
 * pdf生成工具类
 */
public class CreatePDF {

    private static final Logger log = Logger.getLogger(FreemarkerTemplateUtil.class);

    /**
     * 创建PDF文件
     *
     * @param htmlStr
     * @throws Exception
     */
    private static void writeToOutputStreamAsPDF(String htmlStr, File targetFile) throws Exception {

        if (targetFile.exists()) {
            targetFile.delete();
        }

        //定义pdf文件尺寸，采用A4横切
        Document document = new Document(PageSize.A4, 25, 25, 15, 40);// 左、右、上、下间距
        //定义输出路径
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(targetFile));
        writer.setPageEvent(null);
        writer.addViewerPreference(PdfName.PRINTSCALING, PdfName.NONE);
        document.open();

        // CSS
        CSSResolver cssResolver = new StyleAttrCSSResolver();
        CssAppliers cssAppliers = new CssAppliersImpl(new XMLWorkerFontProvider() {

            @Override
            public Font getFont(String fontname, String encoding, boolean embedded, float size, int style, BaseColor color) {
                try {
                    //用于中文显示的Provider
                    BaseFont bfChinese = BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
                    return new Font(bfChinese, size, style);
                } catch (Exception e) {
                    log.error("加载字体失败", e);
                    return super.getFont(fontname, encoding, size, style);
                }
            }
        });

        //html
        HtmlPipelineContext htmlContext = new HtmlPipelineContext(cssAppliers);
        htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());
        htmlContext.setImageProvider(new AbstractImageProvider() {
            @Override
            public Image retrieve(String src) {
                //支持图片显示
                int pos = src.indexOf("base64,");
                try {
                    if (src.startsWith("data") && pos > 0) {
                        byte[] img = Base64.decode(src.substring(pos + 7));
                        return Image.getInstance(img);
                    } else if (src.startsWith("http")) {
                        return Image.getInstance(src);
                    }
                } catch (BadElementException ex) {
                    log.error("加载图片失败", ex);
                    return null;
                } catch (IOException ex) {
                    log.error("加载图片失败", ex);
                    return null;
                }
                return null;
            }

            @Override
            public String getImageRootPath() {
                return null;
            }
        });


        // Pipelines
        PdfWriterPipeline pdf = new PdfWriterPipeline(document, writer);
        HtmlPipeline html = new HtmlPipeline(htmlContext, pdf);
        CssResolverPipeline css = new CssResolverPipeline(cssResolver, html);

        // XML Worker
        XMLWorker worker = new XMLWorker(css, true);
        com.itextpdf.tool.xml.parser.XMLParser p = new com.itextpdf.tool.xml.parser.XMLParser(worker);
        p.parse(new ByteArrayInputStream(htmlStr.getBytes()));

        document.close();
    }

    /**
     * 读取 HTML 文件
     *
     * @return
     */
    private static String readHtmlFile(String filePaht) {
        StringBuffer textHtml = new StringBuffer();
        try {
            File file = new File(filePaht);
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            // 一次读入一行，直到读入null为文件结束
            while ((tempString = reader.readLine()) != null) {
                textHtml.append(tempString);
            }
            reader.close();
        } catch (IOException e) {
            return null;
        }
        return textHtml.toString();
    }

    /**
     * 生成PDF文件
     * 只能读取模板目录下面的文件
     *
     * @param reportData
     * @param templateName
     * @param targetFile
     * @param saveStep     是否保留中间步骤
     * @param
     */

    public static void generateReport(ReportData reportData, String templateName, File targetFile, boolean saveStep) {
        if (!targetFile.getParentFile().exists()) {
            targetFile.getParentFile().mkdirs();
        }
        // 构建数据模型
        Map<String, Object> dataMap = reportData.toMap();
        // 使用FreeMarker处理模板
        String processedHtml = FreemarkerTemplateUtil.processTemplate(templateName, dataMap);

        if (saveStep) {
            // 生成中间文件
            String htmlPath = targetFile.getParentFile().getAbsolutePath() + File.separator + targetFile.getName() + ".html";
            FileUtil.writeUtf8String(processedHtml, htmlPath);
            //        String htmlFile = readHtmlFile(htmlPath);
        }
        try {
            writeToOutputStreamAsPDF(processedHtml, targetFile);
        } catch (Exception e) {
            log.error("生成PDF失败", e);
            throw new ServiceException("生成PDF失败");
        }
    }

    public static void generateReport(ReportData reportData, String templateName, File targetFile) {
        generateReport(reportData, templateName, targetFile, false);
    }
}
