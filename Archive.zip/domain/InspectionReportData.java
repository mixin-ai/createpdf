package com.cn.mdhw.manage.domain.vo;

import com.cn.mdhw.manage.api.ReportData;

import java.util.List;
import java.util.Map;

/**
 * @Author wh
 * @Date 7/23/25
 * @Descripted
 */
public class InspectionReportData implements ReportData {
    private String client="";              // 委托人
    private String orderNumber="";        // 订单号
    private String materialName="";       // 样品名称
    private String gradeName="";          // 样品规格
    private String level="";              // 样品等级
    private String batchNumber="";        // 样品批号
    private String testNumber="";         // 检测号
    private String sendTime="";           // 送样时间
    private String qrCode="";             // 二维码
    private String itemCount="";          // 检项数量
    private List<InspectionItem> items; // 检项列表
    private String receiver="";           // 领检人
    private String printPerson="";        // 打印人
    private String methodRecordTitle="";
    private String methodRecord="";       // 检验方法记录
    private String methodResult="";       // 检验结果

    public static String nextLine(){
        return "<br/>";
    }


    // 构造函数
    public InspectionReportData() {
    }

    public String getMethodRecordTitle() {
        return methodRecordTitle;
    }

    public void setMethodRecordTitle(String methodRecordTitle) {
        this.methodRecordTitle = methodRecordTitle;
    }

    // Getters and Setters
    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getGradeName() {
        return gradeName;
    }

    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public String getTestNumber() {
        return testNumber;
    }

    public void setTestNumber(String testNumber) {
        this.testNumber = testNumber;
    }

    public String getSendTime() {
        return sendTime;
    }

    public void setSendTime(String sendTime) {
        this.sendTime = sendTime;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getItemCount() {
        return itemCount;
    }

    public void setItemCount(String itemCount) {
        this.itemCount = itemCount;
    }

    public List<InspectionItem> getItems() {
        return items;
    }

    public void setItems(List<InspectionItem> items) {
        this.items = items;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getPrintPerson() {
        return printPerson;
    }

    public void setPrintPerson(String printPerson) {
        this.printPerson = printPerson;
    }

    public String getMethodRecord() {
        return methodRecord;
    }

    public void setMethodRecord(String methodRecord) {
        this.methodRecord = methodRecord;
    }

    public String getMethodResult() {
        return methodResult;
    }

    public void setMethodResult(String methodResult) {
        this.methodResult = methodResult;
    }

    /**
     * 转换为FreeMarker数据模型
     */
    public Map<String, Object> toMap() {
        Map<String, Object> dataModel = new java.util.HashMap<>();

        dataModel.put("client", client);
        dataModel.put("orderNumber", orderNumber);
        dataModel.put("materialName", materialName);
        dataModel.put("gradeName", gradeName);
        dataModel.put("level", level);
        dataModel.put("batchNumber", batchNumber);
        dataModel.put("testNumber", testNumber);
        dataModel.put("sendTime", sendTime);
        dataModel.put("QRcode", qrCode);
        dataModel.put("itemCount", itemCount);
        dataModel.put("reciver", receiver);
        dataModel.put("printPerson", printPerson);
        dataModel.put("methodRecord", methodRecord);
        dataModel.put("methodRecordTitle", methodRecordTitle);
        dataModel.put("methodResult", methodResult);

        // 生成检项列表HTML
        if (items != null && !items.isEmpty()) {
            StringBuilder itemListHtml = new StringBuilder();
            for (InspectionItem item : items) {
                itemListHtml.append("<tr style='height: 35px;'>")
                        .append("<td style='width: 20%; text-align: center; height: 35px; padding: 20px 10px 20px 10px;'>").append(item.getName()).append("</td>")
                        .append("<td style='width: 20%; text-align: center; height: 35px; padding: 20px 10px 20px 10px;'>").append(item.getStandard()).append("</td>")
                        .append("<td style='width: 20%; text-align: center; height: 35px; padding: 20px 10px 20px 10px;'>").append(item.getResult()).append("</td>")
                        .append("<td style='width: 25.4313%; text-align: center; height: 35px; padding: 20px 10px 20px 10px;'>").append(item.getRemark()).append("</td>")
                        .append("<td style='width: 14.5687%; text-align: center; height: 35px; padding: 20px 10px 20px 10px;'>").append(item.getWorkHours()).append("</td>")
                        .append("</tr>");
            }
            dataModel.put("itemList", itemListHtml.toString());
        } else {
            dataModel.put("itemList", "");
        }

        return dataModel;
    }
}