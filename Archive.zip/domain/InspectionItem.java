package com.cn.mdhw.manage.domain.vo;

/**
 * @Author wh
 * @Date 7/23/25
 * @Descripted
 */
public class InspectionItem {
    private String name;        // 检项名称
    private String standard;    // 质量标准
    private String result;      // 检测结果
    private String remark;      // 备注
    private String workHours;   // 工时

    public InspectionItem() {
    }

    public InspectionItem(String name, String standard, String result, String remark, String workHours) {
        this.name = name;
        this.standard = standard;
        this.result = result;
        this.remark = remark;
        this.workHours = workHours;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getWorkHours() {
        return workHours;
    }

    public void setWorkHours(String workHours) {
        this.workHours = workHours;
    }
}