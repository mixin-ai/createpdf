package com.cn.mdhw.manage.api;

import java.util.Map;

/**
 * 用于统一表格数据的接口
 * 所有要生成报表的数据表，都要实现这个接口
 */
public interface ReportData {
    Map<String, Object> toMap();
}
