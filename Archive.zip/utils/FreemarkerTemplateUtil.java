package com.cn.mdhw.utils;

import cn.hutool.core.util.StrUtil;
import com.cn.mdhw.common.excepion.ServiceException;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import org.apache.log4j.Logger;

import java.io.*;
import java.util.Map;

/**
 * FreeMarker模板工具类
 * 用于处理HTML模板中的变量替换
 */
public class FreemarkerTemplateUtil {

    private static final Logger log = Logger.getLogger(FreemarkerTemplateUtil.class);
    private static final String rootPath = CreatePDF.class.getClassLoader().getResource("templates").getPath();
    private static Configuration cfg;

    static {
        // 初始化FreeMarker配置
        cfg = new Configuration(Configuration.VERSION_2_3_31);
        try {
            // 设置模板文件目录
            cfg.setDirectoryForTemplateLoading(new File(rootPath));
            // 设置默认编码
            cfg.setDefaultEncoding("UTF-8");
            // 设置异常处理器
            cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
            cfg.setWrapUncheckedExceptions(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 处理模板并返回处理后的HTML字符串
     * @param templateName 模板文件名
     * @param dataModel 数据模型
     * @return 处理后的HTML字符串
     */
    public static String processTemplate(String templateName, Map<String, Object> dataModel) {
        try {
            Template template = cfg.getTemplate(templateName);
            StringWriter out = new StringWriter();
            template.process(dataModel, out);
            String result = out.toString();
            if(StrUtil.isEmpty(result)){
                throw new ServiceException("生成的html为空！");
            }
            return result;
        } catch (Exception e) {
            log.error("生成html失败:",e);
            throw new ServiceException("生成报表失败！");
        }
    }

    public static String getRootPath() {
        return rootPath;
    }
    
    /**
     * 处理模板并输出到文件
     * @param templateName 模板文件名
     * @param dataModel 数据模型
     * @param outputFile 输出文件路径
     */
    public static void processTemplateToFile(String templateName, Map<String, Object> dataModel, String outputFile) {
        try {
            Template template = cfg.getTemplate(templateName);
            FileWriter out = new FileWriter(outputFile);
            template.process(dataModel, out);
            out.close();
        } catch (IOException | TemplateException e) {
            e.printStackTrace();
        }
    }

    /**
     * 处理模板并输出到输出流
     * @param templateName 模板文件名
     * @param dataModel 数据模型
     * @param out 输出流
     */
    public static void processTemplateToStream(String templateName, Map<String, Object> dataModel, Writer out) {
        try {
            Template template = cfg.getTemplate(templateName);
            template.process(dataModel, out);
        } catch (IOException | TemplateException e) {
            e.printStackTrace();
        }
    }
}